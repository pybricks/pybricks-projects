from pybricks import version
from pybricks.tools import wait

print(version)
wait(5000)
print("Hello, World!")
